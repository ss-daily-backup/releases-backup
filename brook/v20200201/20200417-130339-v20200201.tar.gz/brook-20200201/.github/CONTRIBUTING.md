### I want to create a PR.

1. Please create a issue first
1. Don't use internal package
1. Don't use any package manager
1. Single function better than multiple functions
1. Single file better than multiple files
1. Single diretory better than multiple multiple directories
1. Prefer struct and function to be exported.
1. Keep it simple, stupid
1. Please create PR on `master` branch
