// Package crypto provides common crypto libraries for V2Ray.
package crypto // import "v2ray.com/core/common/crypto"

//go:generate errorgen
